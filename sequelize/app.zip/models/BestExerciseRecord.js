module.exports = (sequelize, DataTypes) => {
  const BestExerciseRecord = sequelize.define("BestExerciseRecord", {
    best_exercise_record_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    user_id: DataTypes.INTEGER,
    exercise_record_id: DataTypes.INTEGER,
  });

  return BestExerciseRecord;
};
