const express = require("express");
const app = express();
const sequelize = require("./db");
const userRoutes = require("./routes/user");

app.use(express.json());
app.use("/api/users", userRoutes); // 유저 라우트 등록

sequelize
  .authenticate()
  .then(() => {
    console.log("DB 연결 성공");
    return sequelize.sync({ force: false }); // 테이블 동기화
  })
  .then(() => {
    console.log("테이블 동기화 완료");
    app.listen(8080, () => {
      console.log("서버연결 성공 http://localhost:8080");
    });
  })
  .catch((err) => {
    console.error("DB 연결 또는 동기화 실패", err);
  });
