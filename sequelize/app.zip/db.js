const Sequelize = require("sequelize");

const sequelize = new Sequelize("squadfit", "root", "jaewoo", {
  host: "localhost",
  port: 3307,
  dialect: "mysql",
});

module.exports = sequelize;
